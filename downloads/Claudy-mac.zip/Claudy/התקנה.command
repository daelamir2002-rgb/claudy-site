#!/bin/bash
# Double-click: installs Claudy to ~/Applications and the /claudy skill for Claude Code.
cd "$(dirname "$0")"
./install.sh
echo; echo "Claudy מותקן. אפשר לסגור את החלון."
