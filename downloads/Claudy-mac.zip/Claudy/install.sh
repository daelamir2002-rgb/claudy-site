#!/bin/bash
# Installs Claudy.app to ~/Applications and the /claudy skill to ~/.claude/skills/claudy.
set -euo pipefail
cd "$(dirname "$0")"
ROOT="$PWD"

[ -d "$ROOT/build/Claudy.app" ] || "$ROOT/build.sh"

echo "→ quitting a running Claudy"
osascript -e 'tell application id "local.claudy.app" to quit' >/dev/null 2>&1 || true
for _ in $(seq 1 30); do pgrep -xq Claudy || break; sleep 0.1; done
pkill -x Claudy 2>/dev/null || true

echo "→ app → ~/Applications/Claudy.app"
mkdir -p "$HOME/Applications"
rm -rf "$HOME/Applications/Claudy.app"
cp -R "$ROOT/build/Claudy.app" "$HOME/Applications/Claudy.app"

echo "→ skill → ~/.claude/skills/claudy"
SK="$HOME/.claude/skills/claudy"
rm -rf "$SK"
mkdir -p "$SK"
cp -R "$ROOT/skill/." "$SK/"
chmod +x "$SK"/scripts/*

mkdir -p "$HOME/Library/Application Support/Claudy"

# Hebrew dictation with Whisper (local, ~1.8 GB once). --with-whisper installs without asking, --no-whisper skips.
W="$HOME/Library/Application Support/Claudy/whisper"
if [ -s "$W/model/model.bin" ] && [ -x "$W/venv/bin/python" ]; then
  echo "→ Whisper already installed"
elif [[ " $* " == *" --with-whisper "* ]]; then
  "$ROOT/tools/setup_whisper.sh"
elif [[ " $* " != *" --no-whisper "* ]] && [ -t 0 ]; then
  read -r -p "→ Install local Hebrew dictation (Whisper, downloads ~1.8 GB once)? [y/N] " ans
  if [[ "$ans" =~ ^[Yy] ]]; then "$ROOT/tools/setup_whisper.sh"; else echo "  skipped (run tools/setup_whisper.sh any time)"; fi
else
  echo "→ Whisper not installed (run ./install.sh --with-whisper, or tools/setup_whisper.sh)"
fi
echo "→ launching"
open "$HOME/Applications/Claudy.app"
echo "✓ installed. In any Claude Code session type /claudy"
