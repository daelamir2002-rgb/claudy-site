#!/bin/bash
# One-time setup for Claudy's local Hebrew dictation (Whisper):
#   - a private Python venv with faster-whisper      → ~/Library/Application Support/Claudy/whisper/venv
#   - the ivrit-ai Hebrew Whisper large-v3-turbo model → ~/Library/Application Support/Claudy/whisper/model
# Downloads ~1.8 GB once. After that, transcription runs fully offline.
set -euo pipefail
W="$HOME/Library/Application Support/Claudy/whisper"
MODEL_REPO="ivrit-ai/whisper-large-v3-turbo-ct2"
mkdir -p "$W/model"

echo "→ Python venv"
if [ ! -x "$W/venv/bin/python" ]; then
  /usr/bin/python3 -m venv "$W/venv"
fi
"$W/venv/bin/python" -m pip install --quiet --upgrade pip
"$W/venv/bin/python" -m pip install --quiet "faster-whisper==1.2.1"
echo "  ✓ faster-whisper installed"

echo "→ Hebrew model ($MODEL_REPO)"
for f in config.json preprocessor_config.json tokenizer.json vocabulary.json model.bin; do
  if [ -s "$W/model/$f" ] && [ ! -f "$W/model/$f.part" ]; then echo "  ✓ $f (already there)"; continue; fi
  curl -fL --retry 3 -C - -o "$W/model/$f.part" "https://huggingface.co/$MODEL_REPO/resolve/main/$f"
  mv "$W/model/$f.part" "$W/model/$f"
  echo "  ✓ $f"
done

echo "→ self-test"
"$W/venv/bin/python" - "$W/model" <<'PY'
import sys
from faster_whisper import WhisperModel
try:
    WhisperModel(sys.argv[1], device="mps", compute_type="float16"); print("  ✓ model loads (Apple GPU)")
except Exception:
    WhisperModel(sys.argv[1], device="cpu", compute_type="int8"); print("  ✓ model loads (CPU)")
PY
echo "✓ Whisper ready"
