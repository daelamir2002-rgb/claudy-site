#!/usr/bin/env python3
"""Send one command to the Claudy cursor (validates, then writes command.json atomically).

usage:
  say.py '<json>'                 full command (see SKILL.md for the schema)
  say.py <<'EOF' ... EOF          same, JSON on stdin (best for Hebrew / quotes)
  say.py follow [TEXT...]         follow the mouse, optional bubble text
  say.py point X Y TEXT...        glide to X,Y (points) with a bubble
  say.py text TEXT...             change only the bubble text
  say.py hide | show              hide / show the cursor
  say.py home [TEXT] | out        send Claudy home (asleep in the menu bar) / take it out
  say.py activity search|write|think [TEXT]   show what you're busy with while working
  say.py gesture done|yes|no|wink|oops|sparkle  a wordless reaction (no bubble)
  say.py ask QUESTION [-- A B]    a question with answer buttons (default כן / לא)
  say.py save-lesson NAME         save the current / last lesson to the library
"""
import json
import os
import sys
import tempfile
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import claudy_common  # noqa: E402

claudy_common.utf8_stdout()
D = claudy_common.D
TOP_KEYS = {"x", "y", "text", "rect", "follow", "steps", "title", "app", "bundle", "annotations",
            "visible", "speak", "save_lesson", "seq", "advance", "home",
            "activity", "ask", "choices", "dictation", "id", "gesture",
            "shelf_add", "shelf_remove", "shelf_clear", "project_open", "project_close", "forward", "history", "media"}
STEP_KEYS = {"x", "y", "text", "rect", "annotations", "advance"}
ANN = {  # type -> (required, optional)
    "rect": ({"rect"}, {"label"}),
    "arrow": ({"from", "to"}, {"label"}),
    "drag": ({"from", "to"}, {"label"}),
    "keys": ({"keys"}, {"at", "label"}),
    "marker": ({"at"}, {"n", "label"}),
}

warnings = []


def die(msg):
    print("say.py ERROR: " + msg, file=sys.stderr)
    sys.exit(1)


def is_num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def screens():
    try:
        with open(os.path.join(D, "state.json")) as f:
            return json.load(f).get("screens", [])
    except Exception:
        return []


SCREENS = screens()


def check_on_screen(x, y, where):
    if not SCREENS:
        return
    for s in SCREENS:
        fx, fy, fw, fh = s["frame"]
        if fx - 2 <= x <= fx + fw + 2 and fy - 2 <= y <= fy + fh + 2:
            return
    warnings.append(f"{where}: ({x:.0f},{y:.0f}) is outside every display")


def pt(v, where):
    if not (isinstance(v, list) and len(v) == 2 and all(is_num(a) for a in v)):
        die(f"{where} must be [x, y] numbers")
    check_on_screen(v[0], v[1], where)


def rect(v, where):
    if not (isinstance(v, list) and len(v) == 4 and all(is_num(a) for a in v)):
        die(f"{where} must be [x, y, w, h] numbers")
    if v[2] <= 0 or v[3] <= 0:
        die(f"{where}: width and height must be > 0")
    check_on_screen(v[0], v[1], where)
    check_on_screen(v[0] + v[2], v[1] + v[3], where)


def check_annotations(anns, where):
    if not isinstance(anns, list):
        die(f"{where}.annotations must be a list")
    for i, a in enumerate(anns):
        w = f"{where}.annotations[{i}]"
        if not isinstance(a, dict) or a.get("type") not in ANN:
            die(f"{w}: needs \"type\" one of {sorted(ANN)}")
        req, opt = ANN[a["type"]]
        for k in req:
            if k not in a:
                die(f"{w}: \"{a['type']}\" needs \"{k}\"")
        for k in a:
            if k not in req | opt | {"type"}:
                warnings.append(f"{w}: unknown key \"{k}\" ignored")
        for k in ("from", "to", "at"):
            if k in a:
                pt(a[k], f"{w}.{k}")
        if "rect" in a:
            rect(a["rect"], f"{w}.rect")
        if "keys" in a and not (isinstance(a["keys"], list) and a["keys"] and all(isinstance(k, str) for k in a["keys"])):
            die(f"{w}.keys must be a non-empty list of strings, e.g. [\"⌘\",\"⇧\",\"S\"]")
        if "n" in a and not is_num(a["n"]):
            die(f"{w}.n must be a number")
        if "label" in a and not isinstance(a["label"], str):
            die(f"{w}.label must be a string")


def check_step(s, where, allowed):
    if not isinstance(s, dict):
        die(f"{where} must be an object")
    for k in s:
        if k not in allowed:
            warnings.append(f"{where}: unknown key \"{k}\" ignored")
    if "text" in s and not isinstance(s["text"], str):
        die(f"{where}.text must be a string")
    if ("x" in s) != ("y" in s):
        die(f"{where}: x and y go together")
    if "x" in s:
        if not (is_num(s["x"]) and is_num(s["y"])):
            die(f"{where}: x, y must be numbers (points)")
        check_on_screen(s["x"], s["y"], where)
    if "rect" in s:
        rect(s["rect"], f"{where}.rect")
    if "annotations" in s:
        check_annotations(s["annotations"], where)
    if "advance" in s and s["advance"] not in ("click", "manual"):
        die(f"{where}.advance must be \"click\" or \"manual\"")


def validate(c):
    if not isinstance(c, dict):
        die("command must be a JSON object")
    if any(str(k).startswith("debug") for k in c):
        die("debug keys are not allowed")
    check_step(c, "command", TOP_KEYS)
    if "steps" in c:
        if not (isinstance(c["steps"], list) and c["steps"]):
            die("steps must be a non-empty list")
        for i, s in enumerate(c["steps"]):
            check_step(s, f"steps[{i}]", STEP_KEYS)
            if not s.get("text"):
                warnings.append(f"steps[{i}] has no text")
    for k in ("follow", "visible", "speak", "home"):
        if k in c and not isinstance(c[k], bool):
            die(f"{k} must be true/false")
    if "gesture" in c and c["gesture"] not in ("done", "yes", "no", "wink", "oops", "sparkle"):
        die("gesture must be done | yes | no | wink | oops | sparkle")
    if "activity" in c and c["activity"] not in ("think", "search", "write"):
        die("activity must be think | search | write")
    if "choices" in c and not (isinstance(c["choices"], list) and 1 <= len(c["choices"]) <= 4
                               and all(isinstance(x, str) and x for x in c["choices"])):
        die("choices must be 1–4 non-empty strings")
    if "dictation" in c and not (isinstance(c["dictation"], str) and is_num(c.get("id"))):
        die("dictation needs the formatted text and the numeric id from the dictation message")
    for k in ("title", "app", "bundle", "save_lesson", "ask"):
        if k in c and not isinstance(c[k], str):
            die(f"{k} must be a string")
    if not (TOP_KEYS - {"seq"}) & set(c):
        die("empty command")


def parse_args(a):
    if not a:
        if sys.stdin.isatty():
            die(__doc__)
        return json.loads(sys.stdin.read())
    if a[0] == "-":
        return json.loads(sys.stdin.read())
    if a[0] == "follow":
        c = {"follow": True}
        if a[1:]:
            c["text"] = " ".join(a[1:])
        return c
    if a[0] == "point":
        if len(a) < 3:
            die("point X Y TEXT")
        return {"x": float(a[1]), "y": float(a[2]), "text": " ".join(a[3:])}
    if a[0] == "text":
        return {"text": " ".join(a[1:])}
    if a[0] == "gesture":
        if len(a) < 2:
            die("gesture done|yes|no|wink|oops|sparkle")
        return {"gesture": a[1]}
    if a[0] == "activity":
        if len(a) < 2:
            die("activity think|search|write [TEXT]")
        c = {"activity": a[1]}
        if a[2:]:
            c["text"] = " ".join(a[2:])
        return c
    if a[0] == "ask":
        if len(a) < 2:
            die("ask QUESTION [-- CHOICE1 CHOICE2 ...]")
        rest = a[1:]
        if "--" in rest:
            i = rest.index("--")
            return {"ask": " ".join(rest[:i]), "choices": rest[i + 1:]}
        return {"ask": " ".join(rest)}
    if a[0] in ("home", "out"):
        c = {"home": a[0] == "home"}
        if a[1:]:
            c["text"] = " ".join(a[1:])
        return c
    if a[0] in ("hide", "show"):
        return {"visible": a[0] == "show"}
    if a[0] == "save-lesson":
        return {"save_lesson": " ".join(a[1:]) or "שיעור"}
    if a[0] in ("-h", "--help", "help"):
        print(__doc__)
        sys.exit(0)
    return json.loads(" ".join(a))


def main():
    try:
        cmd = parse_args(sys.argv[1:])
    except json.JSONDecodeError as e:
        die(f"invalid JSON: {e}")
    except ValueError as e:
        die(str(e))
    validate(cmd)
    cmd["seq"] = time.time_ns()
    os.makedirs(D, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=D, prefix=".command.", suffix=".tmp")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(cmd, f, ensure_ascii=False)
    os.replace(tmp, os.path.join(D, "command.json"))
    if not os.environ.get("CLAUDY_BRAIN"):          # Claudy's own Claude is not a /claudy session
        claudy_common.touch("heartbeat")
    n = len(cmd.get("steps", [])) or (1 if ("x" in cmd or "rect" in cmd) else 0)
    kind = "follow" if cmd.get("follow") else (f"{n} step(s)" if n else "text/settings")
    for w in warnings:
        print("warning: " + w, file=sys.stderr)
    if not SCREENS:
        print("warning: state.json missing — is Claudy.app running?", file=sys.stderr)
    print(f"ok: sent {kind}")


if __name__ == "__main__":
    main()
