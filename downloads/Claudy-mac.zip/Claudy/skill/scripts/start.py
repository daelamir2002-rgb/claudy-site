#!/usr/bin/env python3
"""Ensures Claudy is running, skips old inbox lines, greets, and prints the display layout. macOS + Windows."""
import os
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import claudy_common as c  # noqa: E402

c.utf8_stdout()
os.makedirs(c.D, exist_ok=True)

if not c.app_running():
    if not os.path.exists(c.app_path()):
        print(f"ERROR: Claudy is not installed at {c.app_path()}. Run the installer first.")
        sys.exit(1)
    try:
        os.remove(c.path("state.json"))
    except OSError:
        pass
    c.launch_app()
    for _ in range(100):
        if os.path.exists(c.path("state.json")):
            break
        time.sleep(0.1)
    else:
        print("ERROR: Claudy did not start (no state.json).")
        sys.exit(1)

c.touch("inbox.txt")
c.write_text("watcher.cursor", str(c.count_lines()))      # only messages from now on
c.touch("heartbeat")
say = os.path.join(os.path.dirname(os.path.abspath(__file__)), "say.py")
subprocess.run([sys.executable, say, "gesture", "wink"], capture_output=True)   # hello, without a bubble

s = c.state()
print(f"Claudy is running. IO dir: {c.D}")
perm = s.get("screenRecordingPermission", True)
print("Screen capture permission:", "granted" if perm else "NOT granted (messages will arrive without screenshots)")
print("Displays (global coordinates, top-left origin of the main display):")
for d in s.get("screens", []):
    x, y, w, h = d["frame"]
    print(f"  #{d['index']}{' (main)' if d.get('main') else ''} {d.get('name', '')}: "
          f"x={x:g} y={y:g} w={w:g} h={h:g}, {d.get('pixelsPerPoint', 1):g} px/pt")
here = os.path.dirname(os.path.abspath(__file__))
print(f"Now start (Bash, run_in_background: true): python3 {os.path.join(here, 'wait_msg.py')}")
