#!/usr/bin/env python3
"""Claudy's hands: operate apps for a task the user asked for. Claudy.app performs the actions (its orange cursor
glides to every click) and can return a screenshot afterwards. The user stops it by moving the mouse.

usage (JSON on stdin or as one argument):
  act.py <<'EOF'
  {"app":"WhatsApp", "actions":[{"do":"key","keys":"cmd+f"},{"do":"type","text":"אמא"},{"do":"wait","seconds":0.8}],
   "shot": true}
  EOF
  "app" is required for clicks/keys/typing: Claudy brings it to the front and checks before every input.
  act.py shot                      just take a screenshot of the screen now (task window only)
  act.py check                     which permissions Claudy has (accessibility, screenRecording)

actions: open_app{app} · click/double_click/right_click/move{x,y} · type{text} · key{keys:"cmd+f"|"return"|…}
         · scroll{x?,y?,dy,dx?} · wait{seconds}
Coordinates: global points, top-left of the main display (same as say.py / screenshots).
Prints the result JSON; if it includes "shot", Read that image next.
"""
import json
import os
import sys
import tempfile
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import claudy_common as c  # noqa: E402

c.utf8_stdout()
DOS = {"check": set(), "open_app": {"app"}, "click": {"x", "y"}, "double_click": {"x", "y"}, "right_click": {"x", "y"},
       "move": {"x", "y"}, "type": {"text"}, "key": {"keys"}, "scroll": set(), "wait": set()}


def die(m):
    print("act.py ERROR: " + m, file=sys.stderr)
    sys.exit(1)


a = sys.argv[1:]
if a and a[0] == "shot":
    req = {"actions": [], "shot": True}
elif a and a[0] == "check":
    req = {"actions": [{"do": "check"}]}
else:
    raw = " ".join(a) if a else sys.stdin.read()
    try:
        req = json.loads(raw)
    except json.JSONDecodeError as e:
        die(f"invalid JSON: {e}")
if not isinstance(req, dict) or not isinstance(req.get("actions", []), list):
    die('expected {"actions":[…], "shot": true|false}')
for i, x in enumerate(req.get("actions", [])):
    d = x.get("do") if isinstance(x, dict) else None
    if d not in DOS:
        die(f"actions[{i}]: \"do\" must be one of {sorted(DOS)}")
    for k in DOS[d]:
        if k not in x:
            die(f"actions[{i}] ({d}) needs \"{k}\"")
if any(str(k).startswith("debug") for k in req):
    die("debug keys are not allowed")

rid = time.time_ns()
req["id"] = rid
fd, tmp = tempfile.mkstemp(dir=c.D, prefix=".action.", suffix=".tmp")
with os.fdopen(fd, "w", encoding="utf-8") as f:
    json.dump(req, f, ensure_ascii=False)
os.replace(tmp, c.path("action.json"))

limit = 15 + sum(float(x.get("seconds", 0)) for x in req.get("actions", []) if x.get("do") == "wait") \
    + 2 * len(req.get("actions", []))
t0 = time.time()
while time.time() - t0 < limit:
    time.sleep(0.1)
    try:
        with open(c.path("action_result.json"), encoding="utf-8") as f:
            r = json.load(f)
    except (OSError, ValueError):
        continue
    if r.get("id") == rid:
        print(json.dumps(r, ensure_ascii=False))
        if r.get("shot"):
            print(f'Read the screenshot: {r["shot"]}  (x = origin[0] + px/scale, y = origin[1] + py/scale)')
        sys.exit(0 if r.get("ok") else 2)
die("Claudy did not answer (is Claudy.app running?)")
