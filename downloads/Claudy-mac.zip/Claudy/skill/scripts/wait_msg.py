#!/usr/bin/env python3
"""Run with run_in_background. Blocks until the user sends something from Claudy, prints the new inbox
line(s) and exits, so Claude is re-invoked. Keeps the heartbeat fresh while waiting. Unread messages are
never lost: the read position lives in watcher.cursor. macOS + Windows."""
import os
import signal
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import claudy_common as c  # noqa: E402

c.utf8_stdout()
os.makedirs(c.D, exist_ok=True)
c.touch("inbox.txt")
me = os.getpid()

# One watcher at a time: a newer watcher replaces an older one (same or other session).
old = c.read_int("watcher.pid")
if old and old != me and c.pid_alive(old):
    c.kill_pid(old)
c.write_text("watcher.pid", str(me))


def stopped(*_):
    print("CLAUDY: this watcher was stopped (stop ran, or another /claudy watcher took over). "
          "Do NOT restart it unless the user asks.")
    sys.exit(0)


if not c.IS_WIN:
    signal.signal(signal.SIGTERM, stopped)

n = c.read_int("watcher.cursor")
if n is None:
    n = c.count_lines()
started = time.time()

while True:
    total = c.count_lines()
    if total < n:          # inbox was truncated
        n = 0
    if total > n:
        time.sleep(0.2)
        with open(c.path("inbox.txt"), encoding="utf-8") as f:
            lines = f.read().split("\n")
        total = c.count_lines()
        new = [l for l in lines[n:total] if l.strip()]
        print(f"CLAUDY MESSAGE ({len(new)} new):")
        for l in new:
            print(l)
        c.write_text("watcher.cursor", str(total))
        c.touch("heartbeat")
        if c.read_int("watcher.pid") == me:
            os.remove(c.path("watcher.pid"))
        print("---")
        print('Next: Read the "shot" PNG if present, answer with say.py, then start wait_msg.py again with run_in_background.')
        sys.exit(0)
    if c.read_int("watcher.pid") != me:
        print("CLAUDY: another watcher took over. Do NOT restart this one.")
        sys.exit(0)
    if not c.IS_WIN and os.getppid() == 1:     # Claude Code is gone
        sys.exit(0)
    if time.time() - started > 4 * 3600:
        try:
            os.remove(c.path("watcher.pid"))
        except OSError:
            pass
        print("CLAUDY: no message for 4 hours. Start wait_msg.py again with run_in_background to stay connected.")
        sys.exit(0)
    c.touch("heartbeat")
    time.sleep(1)
