"""Shared helpers for the /claudy skill scripts. Works on macOS and Windows (Python 3.8+, stdlib only)."""
import json
import os
import subprocess
import sys
import time

IS_WIN = sys.platform.startswith("win")
IS_MAC = sys.platform == "darwin"


def io_dir():
    """The folder shared by the app and the skill (command.json, inbox.txt, shots/ …)."""
    if IS_WIN:
        return os.path.join(os.environ.get("APPDATA", os.path.expanduser("~\\AppData\\Roaming")), "Claudy")
    return os.path.expanduser("~/Library/Application Support/Claudy")


D = io_dir()


def path(name):
    return os.path.join(D, name)


def touch(name):
    p = path(name)
    with open(p, "a", encoding="utf-8"):
        pass
    os.utime(p, None)


def app_path():
    if IS_WIN:
        return os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "Claudy", "Claudy.exe")
    return os.path.expanduser("~/Applications/Claudy.app")


def app_running():
    try:
        if IS_WIN:
            out = subprocess.run(["tasklist", "/FI", "IMAGENAME eq Claudy.exe", "/NH"],
                                 capture_output=True, text=True).stdout
            return "Claudy.exe" in out
        return subprocess.run(["pgrep", "-xq", "Claudy"]).returncode == 0
    except OSError:
        return False


def launch_app():
    p = app_path()
    if not os.path.exists(p):
        return False
    if IS_WIN:
        subprocess.Popen([p], close_fds=True)
    else:
        subprocess.run(["open", p])
    return True


def quit_app():
    if IS_WIN:
        subprocess.run(["taskkill", "/IM", "Claudy.exe"], capture_output=True)
    else:
        r = subprocess.run(["osascript", "-e", 'tell application id "local.claudy.app" to quit'], capture_output=True)
        if r.returncode != 0:
            subprocess.run(["pkill", "-x", "Claudy"])


def pid_alive(pid):
    if pid <= 0:
        return False
    if IS_WIN:
        out = subprocess.run(["tasklist", "/FI", f"PID eq {pid}", "/NH"], capture_output=True, text=True).stdout
        return str(pid) in out
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def kill_pid(pid):
    try:
        if IS_WIN:
            subprocess.run(["taskkill", "/PID", str(pid), "/F"], capture_output=True)
        else:
            import signal
            os.kill(pid, signal.SIGTERM)
    except OSError:
        pass


def read_int(name):
    try:
        with open(path(name), encoding="utf-8") as f:
            return int(f.read().strip())
    except (OSError, ValueError):
        return None


def write_text(name, s):
    with open(path(name), "w", encoding="utf-8") as f:
        f.write(s)


def count_lines(name="inbox.txt"):
    try:
        with open(path(name), "rb") as f:
            return f.read().count(b"\n")
    except OSError:
        return 0


def state():
    try:
        with open(path("state.json"), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def utf8_stdout():
    """Windows consoles default to a legacy code page; print Hebrew safely."""
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass
