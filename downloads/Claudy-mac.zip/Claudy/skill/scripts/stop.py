#!/usr/bin/env python3
"""Disconnects Claude from Claudy. --quit also quits the app. macOS + Windows."""
import os
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import claudy_common as c  # noqa: E402

c.utf8_stdout()
pid = c.read_int("watcher.pid")
if pid:
    c.kill_pid(pid)
for f in ("watcher.pid", "heartbeat"):
    try:
        os.remove(c.path(f))
    except OSError:
        pass
if "--quit" in sys.argv:
    c.quit_app()
    print("Claudy stopped and quit.")
else:
    if c.app_running():
        say = os.path.join(os.path.dirname(os.path.abspath(__file__)), "say.py")
        subprocess.run([sys.executable, say, "home"], capture_output=True)   # back to sleep, no bubble
    print("Claudy disconnected (app still running).")
