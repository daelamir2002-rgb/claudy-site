#!/usr/bin/env python3
"""List the user's Claude Code projects (the ones the Claude app shows), newest first.

usage: projects.py [words…]      # optional words filter by folder name / conversation title
Prints JSON lines: {"name", "folder", "title", "modified"}. Open one with
say.py '{"project_open":"<folder>","forward":"<the user's request>"}'.
"""
import json
import os
import sys
import time

ROOT = os.path.join(os.path.expanduser("~"), ".claude", "projects")
SKIP = ("/private/tmp", "/tmp", "/scratch-workspaces/", "Claudy/brain")


def first_cwd(f):
    with open(f, "rb") as h:
        for line in h.read(200_000).splitlines():
            try:
                c = json.loads(line).get("cwd")
            except Exception:
                continue
            if c:
                return c


def title(f):
    with open(f, "rb") as h:
        h.seek(0, 2)
        h.seek(max(0, h.tell() - 400_000))
        for line in reversed(h.read().splitlines()):
            if b'"custom-title"' not in line and b'"summary"' not in line:
                continue
            try:
                j = json.loads(line)
            except Exception:
                continue
            t = j.get("customTitle") or (j.get("summary") if j.get("type") == "summary" else None)
            if t:
                return t


def projects():
    out = []
    if not os.path.isdir(ROOT):
        return out
    for d in os.listdir(ROOT):
        dp = os.path.join(ROOT, d)
        files = [os.path.join(dp, f) for f in os.listdir(dp) if f.endswith(".jsonl")] if os.path.isdir(dp) else []
        if not files:
            continue
        latest = max(files, key=os.path.getmtime)
        cwd = first_cwd(latest)
        if not cwd or any(s in cwd for s in SKIP) or not os.path.isdir(cwd):
            continue
        out.append({"name": os.path.basename(cwd.rstrip("/\\")).strip(), "folder": cwd, "title": title(latest),
                    "modified": time.strftime("%Y-%m-%d %H:%M", time.localtime(os.path.getmtime(latest)))})
    seen, unique = set(), []
    for p in sorted(out, key=lambda p: p["modified"], reverse=True):
        if p["folder"] not in seen:
            seen.add(p["folder"])
            unique.append(p)
    return unique


if __name__ == "__main__":
    words = [w.lower() for w in sys.argv[1:] if len(w) > 1]
    for p in projects()[:40]:
        hay = (p["name"] + " " + (p["title"] or "")).lower()
        if not words or any(w in hay for w in words):
            print(json.dumps(p, ensure_ascii=False))
